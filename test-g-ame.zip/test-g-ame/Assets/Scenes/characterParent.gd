extends Node2D
const trail_scene = preload("res://Assets/Scenes/character_trail.tscn")
const part_scene = preload("res://Assets/Scenes/character_particles.tscn")
var delay = 4
var tick = 0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	var trail = trail_scene.instantiate()
	var part = part_scene.instantiate()
	if $CharacterBody2D.pounding == 1 or $CharacterBody2D.wall_jumping == 1:
		trail.global_position = Vector2($CharacterBody2D.position.x, $CharacterBody2D.position.y)
		if $CharacterBody2D.wall_jumping == 1 and $CharacterBody2D.pounding == 1:
			delay = 0
		else:
			delay = 4
		if $CharacterBody2D.wall_jumping == 1:
			tick += 1
			if tick >= delay:
				add_child(trail)
				tick = 0
		else:
			add_child(trail)
	
	if $CharacterBody2D.hit_floor == 1:
		part.global_position = Vector2($CharacterBody2D.position.x, $CharacterBody2D.position.y)
		add_child(part)
		$CharacterBody2D.hit_floor = 0
