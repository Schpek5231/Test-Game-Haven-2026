extends Node

var direction = 1
var wall_jumping = 0
var pounding = 0
var ded = 0
