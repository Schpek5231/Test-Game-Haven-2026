extends Node2D
const trail_scene = preload("res://Assets/Scenes/character_trail.tscn")
const part_scene = preload("res://Assets/Scenes/character_particles.tscn")
const explode_scene = preload("res://Assets/Scenes/explode_particles.tscn")
var delay = 4
var tick = 0
var tick2 = 0
var startx = position.x
var starty = position.y

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	var trail = trail_scene.instantiate()
	var part = part_scene.instantiate()
	var partded = explode_scene.instantiate()
	if Global.pounding == 1 or Global.wall_jumping == 1:
		trail.global_position = Vector2($CharacterBody2D.position.x, $CharacterBody2D.position.y)
		if Global.wall_jumping == 1 and Global.pounding == 1:
			delay = 0
		else:
			delay = 4
		if Global.wall_jumping == 1:
			tick += 1
			if tick >= delay:
				add_child(trail)
				tick = 0
		else:
			add_child(trail)
	
	if $CharacterBody2D.hit_floor == 1:
		part.global_position = Vector2($CharacterBody2D.position.x, $CharacterBody2D.position.y)
		add_child(part)
		$CharacterBody2D.hit_floor = 0
	
	if Global.ded == 1:
		if tick2 == 0:
			partded.global_position = Vector2($CharacterBody2D.position.x, $CharacterBody2D.position.y)
			add_child(partded)
		tick2 += 1
		if tick2 == 240:
			$CharacterBody2D.position.x = startx
			$CharacterBody2D.position.y = starty
			Global.direction = 1
			Global.ded = 0
			tick2 = 0
